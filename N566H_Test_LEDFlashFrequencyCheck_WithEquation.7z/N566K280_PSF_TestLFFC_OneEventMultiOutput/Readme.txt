Notice: 
1. If the debounce time is set to 0 msec for trigger inputs, user must make sure 
   that the input signals are very clean without noise. 
   Otherwise, PowerScript is easy to lose the inputs.
2. The IC will reset to initial states automatically at the below conditions.
   a. WDTEN is enabled but user does not clear watch-dog-timer in the program. 
      uC will reset automatically after 0.5sec @8MHz or 1sec @4MHz. 
      In PowerScript,"PLAYW" and "DELAY" these two instructions will be taken care 
      by library kernel to clear the watch-dog-timer.
   b. LVR will reset all functions into the initial operational state 
      if the power-supply voltage drops below the reference voltage 2.0V +/- 0.2V.
   c. When the programmer disabled all wakeup sources then enter the STOP mode, 
      uC will reset all functions into the initial operational state.
3. In PowerScript, library kernel will reset the stack RAM to initial setting 
    before the program enter sleep mode ("END").


[Part Number]
PartNumber=N566K280

[Configuration]
SIM=Disable
Keypad=0*0
ModePin=0
DirectTrigger=0
Output=1
VolumeMeter=0

ModePin_Debounce=

AudioOutput=PWM
SupportSpeakerSwitch=FALSE
SynthesisLibrary="MM0_BANK0_FIX0.lic"

EventNum=24
InstrumentNum=128

; Optional Function
; - Initial RAM Clear


; SIM Pin Mapping





; Keypad Matrix Mapping
; (Output)
;           
;        (Input)
;


; Mode Pin Mapping

; Direct Trigger Mapping

; Output Pin Mapping
; OUT1 = BP2.4

; Volume Meter Pin Mapping


; Available Scratchpad RAM: R0 ~ R186