	CHIP		N566

   	LONGA OFF
	LONGI OFF

_xCHIP_N566	 EQU 1


BASE_ADDR      		EQU 200H

START1_BLOCK		EQU 00H						
POINTER_L		EQU START1_BLOCK
POINTER_H		EQU START1_BLOCK+1
COUNTER_L		EQU START1_BLOCK+2
COUNTER_H		EQU START1_BLOCK+3

;.PUBLIC SPEAKER_TYPE
;SPEAKER_TYPE 		EQU 1
EXT32MBIT		EQU 1
LIBUSEDRAMCROSSSTACK	EQU 0 
FUNC_CALL_RAM_NUM	EQU 6
RAM_LOCATION_TABLE_COUNT EQU 2	

VOLUME_METER	EQU 0
RANDOM_NUM	EQU 0

OPT_FUNC_0	EQU	0
OPT_FUNC_1	EQU	0
OPT_FUNC_2	EQU	0
OPT_FUNC_3	EQU	0
OPT_FUNC_4	EQU	0
OPT_FUNC_5	EQU	1
OPT_FUNC_6	EQU	0
OPT_FUNC_7	EQU	0
OPT_FUNC_8	EQU	0
;OPT_FUNC_9	EQU	0    ;random
OPT_FUNC_10	EQU	0				  ;0
OPT_FUNC_11	EQU	0
OPT_FUNC_12	EQU	0
OPT_FUNC_13	EQU	0
OPT_FUNC_14	EQU	0


UTIMER_TMA            EQU    0
UTIMER_TMB            EQU    0
UTIMER_FXF10          EQU    0
;========================================================================================================Modified by ydwu 2005.10.19 begin
;Get Portinfo from different W588D chip group
;      .IF	(CHIPBODY='')
;PORTS_NUM	EQU	4      ;BP0 & BP1 & BP2 & IP0
;THREEIO	EQU	1
;      .ENDIF

;      .IF	(CHIPBODY='')
PORTS_NUM  	EQU	3       ;BP0 & BP1 & BP2
THREEIO		EQU	1  
;      .ENDIF

;      .IF	(CHIPBODY='')
;PORTS_NUM	EQU	2       ;BP0 & BP1
;TWOIO		EQU	1
;      .ENDIF

;      .IF	(CHIPBODY='')
;PORTS_NUM	EQU	1       ;BP0
;TWOIO		EQU	1
;      .ENDIF
;=====================================================================================================================  
        .IF     (PORTS_NUM .EQ. 1)  
ONEPORT		 EQU 1

TGP0_NUM     EQU 0		; NUMBER OF 1 IN "TGP0_DEF" 
TGP1_NUM     EQU 0		                                ; NUMBER OF 1 IN "TGP1_DEF"
TGP2_NUM     EQU 0	                                 	; NUMBER OF 1 IN "TGP2_DEF"
TGIP0_NUM    EQU 0		                                ; NUMBER OF 1 IN "TGIP0_DEF"

TGP0_DEF     EQU 00000000B			; 1 = BP0X IS A TG
TGP1_DEF     EQU 00000000B	                        	; 1 = BP1X IS A TG
TGP2_DEF     EQU 00000000B	                          	; 1 = BP2X IS A TG
TGIP0_DEF    EQU 00000000B		                        ; 1 = IP0X IS A TG

MODEP0_DEF   EQU 00000000B			; 1 = BP0X IS A MODE
MODEP1_DEF   EQU 00000000B		                        ; 1 = BP1X IS A MODE
MODEP2_DEF   EQU 00000000B	                         	; 1 = BP2X IS A MODE
MODEIP0_DEF  EQU 00000000B                            		; 1 = IP0X IS A MODE

MODEP0_LOW   EQU 11111111B			; 0 = BP0X IS A MODE
MODEP1_LOW   EQU 11111111B		                        ; 0 = BP1X IS A MODE
MODEP2_LOW   EQU 11111111B		                        ; 0 = BP2X IS A MODE
MODEIP0_LOW  EQU 11111111B	                          	; 0 = IP0X IS A MODE

MXINP0_DEF   EQU 00000000B		; 1 = BP0X IS A MATRIX INPUT 
MXINP1_DEF   EQU 00000000B	                            	; 1 = BP1X IS A MATRIX INPUT 
MXINP2_DEF   EQU 00000000B		; 1 = BP2X IS A MATRIX INPUT
MXINIP0_DEF  EQU 00000000B		; 1 = IP0X IS A MATRIX INPUT

MXOUTP0_DEF  	EQU 11111111B     ; ADD,according to spec
MXOUTP1_DEF  	EQU 00000000B          				; ADD,according to spec
MXOUTP2_DEF  	EQU 00000000B          				; ADD,according to spec
MXOUTIP0_DEF  	EQU 00000000B        				; ADD,according to spec

OUTP0_DEF    	EQU 11111100B          	; ADD,according to spec 
OUTP1_DEF    	EQU 00000000B          				; ADD,according to spec 
OUTP2_DEF    	EQU 00000000B          				; ADD,according to spec 
OUTIP0_DEF    	EQU 00000000B          				; ADD,according to spec 
        .ENDIF
        
        
	.IF     (PORTS_NUM .EQ. 2)
TGP0_NUM     EQU 0		; NUMBER OF 1 IN "TGP0_DEF" 
TGP1_NUM     EQU 0		; NUMBER OF 1 IN "TGP1_DEF"
TGP2_NUM     EQU 0	                                 	; NUMBER OF 1 IN "TGP2_DEF"
TGIP0_NUM    EQU 0		                                ; NUMBER OF 1 IN "TGIP0_DEF"

TGP0_DEF     EQU 00000000B		        ; 1 = BP0X IS A TG
TGP1_DEF     EQU 00000000B		        ; 1 = BP1X IS A TG
TGP2_DEF     EQU 00000000B	                          	; 1 = BP2X IS A TG
TGIP0_DEF    EQU 00000000B		                        ; 1 = IP0X IS A TG

MODEP0_DEF   EQU 00000000B	              	; 1 = BP0X IS A MODE
MODEP1_DEF   EQU 00000000B		        ; 1 = BP1X IS A MODE
MODEP2_DEF   EQU 00000000B	                         	; 1 = BP2X IS A MODE
MODEIP0_DEF  EQU 00000000B                            		; 1 = IP0X IS A MODE

MODEP0_LOW   EQU 11111111B		        ; 0 = BP0X IS A MODE
MODEP1_LOW   EQU 11111111B	          	; 0 = BP1X IS A MODE
MODEP2_LOW   EQU 11111111B		                        ; 0 = BP2X IS A MODE
MODEIP0_LOW  EQU 11111111B	                          	; 0 = IP0X IS A MODE

MXINP0_DEF   EQU 00000000B		; 1 = BP0X IS A MATRIX INPUT 
MXINP1_DEF   EQU 00000000B		; 1 = BP1X IS A MATRIX INPUT
MXINP2_DEF   EQU 00000000B		; 1 = BP2X IS A MATRIX INPUT
MXINIP0_DEF  EQU 00000000B		; 1 = IP0X IS A MATRIX INPUT

MXOUTP0_DEF  	EQU 11111111B        ; ADD,according to spec
MXOUTP1_DEF  	EQU 11111111B        ; ADD,according to spec
MXOUTP2_DEF  	EQU 00000000B					   ; ADD,according to spec
MXOUTIP0_DEF  	EQU 00000000B        				   ; ADD,according to spec

OUTP0_DEF    	EQU 11111111B          	; ADD,according to spec 
OUTP1_DEF    	EQU 11111100B          	; ADD,according to spec 
OUTP2_DEF    	EQU 00000000B          				; ADD,according to spec 
OUTIP0_DEF    	EQU 00000000B          				; ADD,according to spec 
       .ENDIF
       
       
       .IF     (PORTS_NUM .EQ. 3)       
TGP0_NUM     EQU 0		; (BP0) NUMBER OF 1 IN "TGP0_DEF"
TGP1_NUM     EQU 0		; (BP1) NUMBER OF 1 IN "TGP1_DEF"
TGP2_NUM     EQU 0		; (BP2) NUMBER OF 1 IN "TGP2_DEF"
TGIP0_NUM    EQU 0					        ; NUMBER OF 1 IN "TGIP0_DEF"

TGP0_DEF     EQU 00000000B		        ; (BP0) 1 = BP0X IS A TG
TGP1_DEF     EQU 00000000B		        ; (BP1) 1 = BP1X IS A TG
TGP2_DEF     EQU 00000000B	          ; (BP2) 1 = BP2X IS A TG
TGIP0_DEF    EQU 00000000B					; 1 = IP0X IS A TG

MODEP0_DEF   EQU 00000000B		        ; (BP0) 1 = BP0X IS A MODE
MODEP1_DEF   EQU 00000000B		        ; (BP1) 1 = BP1X IS A MODE
MODEP2_DEF   EQU 00000000B		        ; (BP2) 1 = BP2X IS A MODE
MODEIP0_DEF  EQU 00000000B					; 1 = IP0X IS A MODE

MODEP0_LOW   EQU 11111111B	          ; (BP0) 0 = BP0X IS A MODE
MODEP1_LOW   EQU 11111111B		        ; (BP1) 0 = BP1X IS A MODE
MODEP2_LOW   EQU 11111111B		        ; (BP2) 0 = BP2X IS A MODE
MODEIP0_LOW  EQU 11111111B					; 0 = IP0X IS A MODE

MXINP0_DEF   EQU 00000000B		; (BP0) 1 = BP0X IS A MATRIX INPUT 
MXINP1_DEF   EQU 00000000B		; (BP1) 1 = BP1X IS A MATRIX INPUT
MXINP2_DEF   EQU 00000000B		; (BP2) 1 = BP2X IS A MATRIX INPUT
MXINIP0_DEF  EQU 00000000B					; 1 = IP0X IS A MATRIX INPUT

MXOUTP0_DEF  	EQU 11111111B        ; (BP0) ADD,according to spec
MXOUTP1_DEF  	EQU 11111111B        ; (BP1) ADD,according to spec
MXOUTP2_DEF  	EQU 11111111B        ; (BP2) ADD,according to spec
MXOUTIP0_DEF  	EQU 00000000B        				   ; ADD,according to spec

OUTP0_DEF    	EQU 11111100B          	; (BP0) ADD,according to spec 
OUTP1_DEF    	EQU 11111111B          	; (BP1) ADD,according to spec 
OUTP2_DEF    	EQU 11111111B          	; (BP2) ADD,according to spec 
OUTIP0_DEF    	EQU 00000000B          				; ADD,according to spec 
	.ENDIF
	

        .IF     (PORTS_NUM .EQ. 4) 
TGP0_NUM     EQU 0		; NUMBER OF 1 IN "TGP0_DEF" 
TGP1_NUM     EQU 0		; NUMBER OF 1 IN "TGP1_DEF"
TGP2_NUM     EQU 0		; NUMBER OF 1 IN "TGP2_DEF"
TGIP0_NUM    EQU 0		; NUMBER OF 1 IN "TGIP0_DEF"

TGP0_DEF     EQU 00000000B		        ; 1 = BP0X IS A TG/MODE,Other bit is 0
TGP1_DEF     EQU 00000000B		        ; 1 = BP1X IS A TG/MODE,Other bit is 0
TGP2_DEF     EQU 00000000B		        ; 1 = BP2X IS A TG/MODE,Other bit is 0
TGIP0_DEF    EQU 00000000B		        ; 1 = IP0X IS A TG/MODE,Other bit is 0

MODEP0_DEF   EQU 00000000B		        ; 1 = BP0X IS A MODE,Other bit is 0
MODEP1_DEF   EQU 00000000B		        ; 1 = BP1X IS A MODE,Other bit is 0
MODEP2_DEF   EQU 00000000B		        ; 1 = BP2X IS A MODE,Other bit is 0
MODEIP0_DEF  EQU 00000000B		        ; 1 = IP0X IS A MODE,Other bit is 0

MODEP0_LOW   EQU 11111111B		        ; 0 = BP0X IS A MODE,Other bit is 1
MODEP1_LOW   EQU 11111111B		        ; 0 = BP1X IS A MODE,Other bit is 1
MODEP2_LOW   EQU 11111111B		        ; 0 = BP2X IS A MODE,Other bit is 1
MODEIP0_LOW  EQU 11111111B		        ; 0 = IP0X IS A MODE,Other bit is 1

MXINP0_DEF   EQU 00000000B		; 1 = BP0X IS A MATRIX INPUT,Other bit is 0 
MXINP1_DEF   EQU 00000000B		; 1 = BP1X IS A MATRIX INPUT,Other bit is 0
MXINP2_DEF   EQU 00000000B		; 1 = BP2X IS A MATRIX INPUT,Other bit is 0
MXINIP0_DEF  EQU 00000000B		; 1 = IP0X IS A MATRIX INPUT,Other bit is 0

MXOUTP0_DEF  	EQU 11111111B        ; ADD,according to spec
MXOUTP1_DEF  	EQU 11111111B        ; ADD,according to spec
MXOUTP2_DEF  	EQU 11111111B        ; ADD,according to spec
MXOUTIP0_DEF  	EQU 00000000B        				   ; ADD,according to spec

OUTP0_DEF    	EQU 11111100B          	; ADD,according to spec 
OUTP1_DEF    	EQU 11111111B          	; ADD,according to spec 
OUTP2_DEF    	EQU 11111111B          	; ADD,according to spec 
OUTIP0_DEF    	EQU 00000000B          				; ADD,according to spec 
	.ENDIF

MODEPIN_NUM  	EQU 0
MXOUT_PORT_NUM EQU 0
MXIN_PORT_NUM  EQU 0

MXOUT_NUM    EQU 0			; NUMBER OF MATRIX OUTPUT PIN
MXIN_NUM     EQU 0			; NUMBER OF MATRIX INPUT PIN

;================================================================================================
.IF OPT_FUNC_0 .GT. 0
ENTIMER	EQU	1
.ENDIF

.IF OPT_FUNC_1 .GT. 0
INTCAP	EQU	1
.ENDIF

.IF OPT_FUNC_2 .GT. 0
PORTISR	EQU	1
.ENDIF

.IF OPT_FUNC_3 .GT. 0
USERRTC	EQU	1
.ENDIF
	
.IF OPT_FUNC_4 .GT. 0
CROSSBANK	EQU	1
.ENDIF

.IF OPT_FUNC_5 .GT. 0
INITRAMCLEAR	EQU	1
.ENDIF

.IF OPT_FUNC_6 .GT. 0
ENSLEEP	EQU	1
.ENDIF

.IF OPT_FUNC_7 .GT. 0
MULTITIMER	EQU	1
.ENDIF

.IF OPT_FUNC_8 .GT. 0
IR_CARRIER	EQU	1
.ENDIF

.IF OPT_FUNC_10 .GT. 0
VOLUME_VC   EQU     1
.ENDIF

.IF OPT_FUNC_11 .GT. 0
USER_FXF13   EQU     1
.ENDIF

.IF OPT_FUNC_12 .GT. 0
USER_FXF15   EQU     1
.ENDIF

.IF OPT_FUNC_13 .GT. 0
USER_FXF10   EQU     1
.ENDIF

.IF OPT_FUNC_14 .GT. 0
LVDEN   EQU     1
.ENDIF

.IF RANDOM_NUM .GT. 0
RANDOM	EQU	1
.ENDIF

.IF VOLUME_METER .GT. 0
VOLUME_VM   EQU     1
.ENDIF

.IF EXT32MBIT .GT. 0
ENEXT32MBIT	EQU 1
.ENDIF

.IF FUNC_CALL_RAM_NUM .GT. 0
ENFUNCCALL EQU 1
.ENDIF

;OPT_FUNC_10+VOLUME_METER=0
.IF OPT_FUNC_1+OPT_FUNC_11+OPT_FUNC_12+OPT_FUNC_13 .GT. 0
FLAG1_EXIST EQU 1
.ENDIF

KEYMATRIX_DELAY	EQU 0

.IF UTIMER_FXF10 .GT. 0
UT_FXF10	EQU	1
.ENDIF

.IF UTIMER_TMA .GT. 0
UT_TMA	EQU	1
.ENDIF

.IF UTIMER_TMB .GT. 0
UT_TMB	EQU	1
.ENDIF
;----------------------------------------------------------------------
.IF MXIN_NUM .GT. 0
.IF MXOUT_NUM .GT. 0
MATRIX	EQU	1
.ENDIF
.ENDIF

.IF TGP0_NUM+TGP1_NUM+TGP2_NUM+TGIP0_NUM .GT. 0
DIRTG	EQU	1
.ENDIF

.IF MODEPIN_NUM .GT. 0
SWMODE	EQU	1
.ENDIF

.IF TGP0_NUM+TGP1_NUM+TGP2_NUM+TGIP0_NUM+MXIN_NUM+MXOUT_NUM+MODEPIN_NUM .GT. 0
KEY_TG	EQU	1
.ENDIF

.IF TGP0_NUM .GT. 0
BP0TG	EQU	1
.ENDIF

.IF TGP1_NUM .GT. 0
BP1TG	EQU	1
.ENDIF

.IF TGP2_NUM .GT. 0
BP2TG   EQU     1
.ENDIF

.IF TGIP0_NUM .GT. 0
IP0TG   EQU     1
.ENDIF

.IF MXINP0_DEF+TGP0_NUM .GT. 0
BP0USED   EQU     1
.ENDIF

.IF MXINP1_DEF+TGP1_NUM .GT. 0
BP1USED   EQU     1
.ENDIF

.IF MXINP2_DEF+TGP2_NUM .GT. 0
BP2USED   EQU     1
.ENDIF

.IF MXINIP0_DEF+TGIP0_NUM .GT. 0
IPOUSED   EQU     1
.ENDIF

.IF KEYMATRIX_DELAY .GT. 0
MATRIX_DELAY	EQU	1
.ENDIF

ABANDON_STACK_EXIST EQU OPT_FUNC_8+TGP0_NUM+TGP1_NUM+TGP2_NUM+TGIP0_NUM+MXIN_NUM+MXOUT_NUM+MODEPIN_NUM

.IF ABANDON_STACK_EXIST .GT. 0
ABANDON_STACK	EQU	1
.ENDIF




